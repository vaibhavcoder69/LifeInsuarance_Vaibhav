package com.mindtree.app.UserRepo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.app.UserModel.PolicyModel;



@Repository
public interface PolicyRepo extends JpaRepository<PolicyModel,Integer> {


}