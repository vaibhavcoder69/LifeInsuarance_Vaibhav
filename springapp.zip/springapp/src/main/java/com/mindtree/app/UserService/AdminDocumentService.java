package com.mindtree.app.UserService;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.mindtree.app.UserModel.DocumentModel;
import com.mindtree.app.UserModel.PolicyModel;
import com.mindtree.app.UserRepo.DocumentRepo;
import com.mindtree.app.UserRepo.PolicyRepo;

@Service
public class AdminDocumentService {
              @Autowired
              private DocumentRepo adminrepository;
              @Autowired
              private PolicyRepo policyservice;
              public DocumentModel saveDocument(MultipartFile file, int policyId) throws IOException{
              String fileName = StringUtils.cleanPath(file.getOriginalFilename());
    String fileType = file.getContentType();
              byte[] fileData = file.getBytes();
              DocumentModel nfile = new DocumentModel();
              
    nfile.setDocumenttype(fileType);
    nfile.setDocumentupload(fileData);
    PolicyModel l=policyservice.findById(policyId).get();
    nfile.setPolicy(l);
              return adminrepository.save(nfile);
              }
              public List<DocumentModel> viewDocument(){

                return adminrepository.findAll();
                }
}
