package com.mindtree.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LifeInsurancePortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(LifeInsurancePortalApplication.class, args);
	}

}
